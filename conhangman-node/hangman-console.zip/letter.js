var Letter = function(let) {
	//make a charac property and set it to what you think makes second_instructor_demonstration
	
	//make an appear property and set it to what makes sense

	//make a letterRender property and set it to a function that does what you think makes sense

};

//export the Letter constructor here